
export default function App() {
  return (
    <div style={{padding:40,fontFamily:'sans-serif'}}>
      <h1>VConnect 🚀</h1>
      <p>Your hackathon-ready build is working.</p>
    </div>
  );
}
