
export function Button({ children, ...props }: any) {
  return <button style={{padding:'8px 16px',borderRadius:8}} {...props}>{children}</button>;
}
