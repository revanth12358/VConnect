# VConnect

Hackathon-ready Internet Computer app.
